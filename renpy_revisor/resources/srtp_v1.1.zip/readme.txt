Simple Ren'Py Tool v1.0
=================================================

Simple Ren'Py Tool (srt.exe) is a Windows console utility for Ren'Py games.
It is meant as a safer unpack / decompile helper — an analog of UnRen:
extract .rpa archives, decompile .rpyc / .rpymc, optionally compare engine
files to an SDK catalog, and write small gameplay tweaks into game\zzzz.rpy.

If you start the program with no operation flags, a console menu is
shown. If you pass -e, -d or -c, it runs in CLI mode.

Place libzstd.dll next to srt.exe (ZIP methods 93/20). Without it the
program will not start. sdk.ref and renpytweaks.txt are optional.

1. Features
-----------

Extract
  Unpacks files from .rpa archives into a destination folder. An optional
  filename mask (for example *.rpy*) limits which entries are written.
  A relative destination is resolved against the folder being processed,
  not against the folder of srt.exe. An empty mask extracts everything.
  Menu I (CLI -i) switches to in-place: each archive unpacks into the
  folder that contains that .rpa, keeping member subpaths.

Decompile .rpyc / .rpymc
  Turns compiled scripts into .rpy / .rpym text and writes them into the
  extract folder (default: unpack), keeping the relative path under the
  target. Loose files on disk are decompiled. Scripts packed inside an
  .rpa are decompiled too unless skip-packed is on (menu S or -b):
  a folder target writes them under <archive-stem>_rpa\, a single .rpa
  file writes them straight into the extract folder.
  In-place (menu I / -i): loose scripts are written next to the original
  .rpyc/.rpymc; packed scripts use the member path relative to the .rpa.

Skip packed .rpyc / .rpymc
  When enabled, .rpyc/.rpymc inside .rpa are not decompiled. Only flips
  a flag; it does not start a task.

SDK compare (needs sdk.ref next to srt.exe)
  Meant mainly to check specific files when you doubt them (known / unknown
  against the catalog, or how a game tree differs from that SDK version) —
  not as a malware / infection check.
  A file target has no extra menu item: under Target the program shows
  known (engine version(s), and the original catalog name if the file
  stem differs) or unknown. The engine tree is not searched.
  A folder target gets a numbered menu item "Check with the Ren'Py SDK":
  detect the engine, read the version, compare lib\, renpy\ and launchers
  to the catalog. If that version is missing from the catalog, a warning
  is printed; compare still runs. A .zip that contains game\ + renpy\ is
  compared the same way (members hashed in memory). CLI: -c / --check.

Tweaks Ren'Py (needs renpytweaks.txt next to srt.exe)
  Shown only when the target is a game root, the game\ folder, or a .zip
  with game\ + renpy\ (zzzz.rpy is written on disk under the virtual root,
  e.g. Foo.zip → Foo\game\zzzz.rpy). Writes game\zzzz.rpy from the tweaks
  you turn ON (an existing zzzz.rpy is not read). Submenu: all tweaks start
  OFF; 1..n toggle; A write (and remove a sibling .rpyc); D delete
  zzzz.rpy/.rpyc; 0 back. Numbers are 1-9 then 10-99 (no leading zero).

Custom signatures and encrypted indexes
  RPA headers other than RPA-2.0 / RPA-3.0 / RPA-3.2, and RPYC headers
  other than "RENPY RPC2", are accepted and produce a warning. A specific
  XOR encoding of the RPA index is detected, accepted, and reported as
  "encrypted index".

WoS containers
  Files that use the WoS container format are detected and skipped with a
  warning; they are not extracted or decompiled.


2. Supported formats
--------------------

  .rpa              Ren'Py archive (RPA-2.0, RPA-3.0, RPA-3.2, custom
                    signatures, XOR-encrypted index)
  .rpyc / .rpymc    compiled scripts (decompiled on disk and, unless
                    skipped, from inside .rpa)
  .zip              virtual folder (extract / decompile / SDK). Nested
                    .zip members inside an archive are skipped. On-disk
                    .zip files under a folder target are each a virtual
                    folder. Virtual root: Foo.zip → Foo\. Nothing is
                    written back into the zip. Methods 93/20 need
                    libzstd.dll next to srt.exe.

A folder target is processed recursively (including on-disk .zip files).
A file target is handled according to its extension (.zip = folder walk).


3. Console GUI
--------------

Copy srt.exe into the game folder (or any folder that contains the files)
and run it with no flags. The current directory of the executable is used
as the default target. You can also pass only a path:

  srt.exe D:\Games\MyGame

The menu shows Target, then:

  1 - Extract
      Unpack matching .rpa entries to the extract folder.

  2 - Decompile
      Decompile .rpyc / .rpymc on disk and, unless skipped, inside .rpa.

Further numbers depend on sdk.ref and whether the target is a game:

  A file target with sdk.ref shows known/unknown under Target; there is
  no SDK menu item (.zip is treated as a folder, not hashed as one file).

  T - Change target
      File or folder. Relative paths are resolved against the current
      target folder. The path must already exist.

  E - Change extract path
      Destination for extract and decompile. Default: unpack (under the
      target folder). May be relative or absolute. Current value is shown
      on the menu line. Unused while in-place (I) is on.

  M - Change mask
      Filename pattern for extract (for example *.rpy*). Empty = all
      files. Current value is shown on the menu line.

  I - Toggle unpack/decompile destination
      extract folder (default, uses E) or in-place (beside each file /
      archive). Only flips the flag; it does not start a task.

  S - Toggle skip packed .rpyc/.rpymc inside .rpa
      Only flips the flag; it does not start a task. Current state
      (process / skip) is shown on the line.

  0 - Exit

Tweaks submenu:

  1..n  Toggle ON/OFF (all start OFF each time you enter)
  A     Write game\zzzz.rpy
  D     Delete zzzz.rpy / zzzz.rpyc
  0     Back

While a task runs, the console shows the current file and warnings
(custom signature, encrypted index, WoS). Exceptions are also written to
errorlog_YYYYMMDDHHMMSS.txt next to srt.exe. At the end it prints a
summary: processed count, warnings, errors, and elapsed time.

Typical workflow:

  1. Run srt.exe in (or with) the game folder.
  2. Check Target / Extract path / Mask / in-place (T, E, M, I).
  3. Choose 1 to unpack, 2 to decompile, SDK compare, or tweaks.


4. Command-line mode
--------------------

CLI mode starts when at least one of -e, -d or -c is present. The
interactive menu is not shown. Detailed console output is suppressed
except for -c (known/unknown or the folder compare report). Warnings and
errors are not printed to the console; exceptions go to
errorlog_YYYYMMDDHHMMSS.txt next to srt.exe.

Syntax (all arguments are optional):

  srt.exe [target] [-e path] [-d path] [-m mask] [-b] [-i] [-c]

  target              File or folder to process. Relative paths are
                      resolved against the folder of srt.exe. If omitted,
                      that folder is used.

  -e, --extract path  Extract .rpa contents to this folder and enter CLI
                      mode. A relative path is resolved against the folder
                      being processed. If -e is given without a path, the
                      flag is ignored unless -i is also set.

  -d, --decompile [path]
                      Decompile .rpyc/.rpymc (loose and packed) into this
                      folder (same destination as extract) and enter CLI
                      mode. The flag itself enables decompile; the next
                      non-flag token is the destination. Combined with -e,
                      extract wins and decompile is turned off (no error).

  -m, --mask mask     Filename pattern for extract (for example *.rpy*).
                      Used together with -e.

  -b, --no-packed     Skip .rpyc/.rpymc inside .rpa when decompiling.

  -i, --in-place      Extract and decompile beside the source instead of
                      the extract folder. Loose .rpyc → sibling .rpy;
                      .rpa members keep their archive path under the
                      folder of that .rpa. Use with -e and/or -d.
                      -e without a path is enough when -i is set.

  -c, --check         CLI SDK lookup. A file prints one line: known or
                      unknown. A folder or a game .zip prints the engine
                      version and a compare report. Needs sdk.ref next
                      to srt.exe.

CLI stdout (extract / decompile):

  Warnings and errors are not printed. Exceptions are written only to
  errorlog_YYYYMMDDHHMMSS.txt next to srt.exe (created only if at least
  one error occurred). Last line:

    Done. M

  M = files processed.

Examples:

  srt.exe D:\Games\MyGame -e unpack -m *.rpy*
      Extract scripts from all .rpa files into D:\Games\MyGame\unpack.

  srt.exe D:\Games\MyGame -d out
      Decompile loose and packed scripts into D:\Games\MyGame\out.

  srt.exe D:\Games\MyGame -e unpack -d out
      Extract only (extract wins over decompile). Destination is the last
      path token (`out`).

  srt.exe D:\Games\MyGame -d out -b
      Decompile loose scripts only; skip packed .rpyc inside .rpa.

  srt.exe D:\Games\MyGame -e -i
      Extract every .rpa into the folder that contains that archive.

  srt.exe D:\Games\MyGame -d -i
      Decompile loose scripts next to the .rpyc; packed scripts next to
      their .rpa, using the member path.

  srt.exe D:\Games\MyGame\renpy.exe -c
      Print known or unknown for one file.

  srt.exe D:\Games\MyGame -c
      Compare a game folder to sdk.ref.

  srt.exe D:\Games\Foo.zip -c
      Same as a folder compare, using zip members.


5. Explorer context menu
------------------------

install.bat (run as Administrator) registers a "Check RPA files" item for
files and folders. It starts:

  srt.exe "<selected path>"

Because no -e/-d/-c flag is passed, the console menu opens with that path
as Target.

uninstall.bat (Administrator) removes the registry entry.


6. Output files
---------------

  unpack\...          Default extract / decompile destination
  <archive-stem>_rpa\ Packed decompile output when the target is a folder
  game\zzzz.rpy       Tweaks script written by the tweaks submenu (A)
  errorlog_YYYYMMDDHHMMSS.txt
                      Exceptions during Solve (beside srt.exe; only if any
                      error occurred). Menu shows them on the console too;
                      CLI writes them only here.


7. Troubleshooting
------------------

Decompile is the most common place things go wrong: unknown pickle
opcodes, Screen Language constructs the port does not cover, or a
file that is not a normal Ren'Py .rpyc. The task then logs an error for
that file (errorlog next to srt.exe; also on the console in menu mode)
and continues with the rest.

If you hit a bug, send:

  - errorlog_*.txt from the folder of srt.exe (when present)
  - the file(s) that failed (a single .rpyc / .rpa is enough when the
    problem is decompile or extract)

Do not expect an immediate fix. This is volunteer work, shipped as is.


Changelog
=========
03.10.2026, version 1.1:
- For RPA, new decoding methods and heuristics to overcome index obsfurcation.
- Updated the SDK base with nightly builds (thanks to Bob69).
- Bugfix

20.09.2026, version 1.0hf1:
- SDK check bug has been fixed

19.09.2026, version 1.0:
- .zip is treated as a virtual folder (extract / decompile / SDK).
- libzstd.dll for ZIP methods 93/20 (zstd).
- In-place extract/decompile (menu I / -i).
- Solve exceptions → errorlog_YYYYMMDDHHMMSS.txt beside srt.exe. 
- Banner / title.
- Bugfix.

12.09.2026, version 0.8:
- Menu reworked
- Decompile of .rpyc / .rpymc packed inside .rpa (unless skip packed).
- Screen language 1 decompile in the unrpyc port.
- SDK compare (sdk.ref) and CLI -c.
- Tweaks submenu writes game\zzzz.rpy.

04.09.2026, version 0.7:
- Decompile of .rpyc / .rpymc into the extract folder.

03.09.2026, version 0.6:
- RPA works correctly with custom signatures.
- Detection of a specific XOR encoding used by some RPA files.
- Custom signatures for RPYC.
- Several bugs fixed.

23.06.2026, version 0.5:
- Command-line extract: [target] [-e path] [-m mask].
- Console menu when started without operation flags.
