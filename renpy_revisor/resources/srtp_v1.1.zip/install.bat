reg add HKCR\AllFilesystemObjects\shell\SRT /ve /f /d "Simple Renpy Tool"
reg add HKCR\AllFilesystemObjects\shell\SRT\command /ve /f /d "\"%~dp0srt.exe\" \"%%1\"" 